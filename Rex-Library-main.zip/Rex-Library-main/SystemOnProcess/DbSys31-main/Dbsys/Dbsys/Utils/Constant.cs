﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dbsys
{
    public enum ErrorCode
    {
        Success = 0,
        Error = 1
    }

    public enum Role
    {
        Student = 1,
        Teacher = 2,
        Admin = 3

    }
    public class Constant
    {
       
    }
}
